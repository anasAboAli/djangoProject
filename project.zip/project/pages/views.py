from django.shortcuts import render
def index(request):
    context={
        "full_name":"أنس الحرثاني",
        "student_id":"120221871",
        "address":"غزة"
    }
    return render(request,"pages/index.html",context)
